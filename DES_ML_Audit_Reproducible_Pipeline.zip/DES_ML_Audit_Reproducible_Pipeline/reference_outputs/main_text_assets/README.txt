Main-text tables and figures generated for the DES leakage-aware benchmark manuscript.
Figure 1 is a conceptual workflow graphic and is generated separately by scripts/17_build_main_figure1_audit_workflow.py.
